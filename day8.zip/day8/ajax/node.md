
# json js对象表示法：  前后端交互的数据格式；前  后端分离

js   <------>   php java ph .net

1. json数据的表示方法是 [{}] {key: []}
2. json中除了 boolean 和 number 都必须用双引号
3. json末尾不能加标点
4. 只接受 number null boolean string  不接受 undefined;


5. 使用json 必须使用ajax 技术  去通过路径请求；并且设置请求方式，和回调函数



# 起服务 go live;
# ajax('./data.json', function(res) {
#})

#  ajax 使用真实环境中。需要传递参数，（告诉后端你需要什么样数据）

请求方式：
请求路径
传递参数
回调函数接受数据


