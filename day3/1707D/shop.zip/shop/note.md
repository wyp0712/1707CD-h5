移动开发：

原生app: native App
  ios: Object-c
  安卓： java
webApp:

混合app: hybird App;

 原生的框架，h5页面；