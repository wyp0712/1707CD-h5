#动画

自执行：

animation: name 2s 0s infinite linear alternate ;

@keyframes name{}


# touch


tap: 单击事件

longTag: 长按事件

slideLeft：左滑