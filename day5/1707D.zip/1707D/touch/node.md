#touch


1. touchstart

2. touchmove

3. touchend



tap：

longTap:

swipeLeft:

swipeRight: